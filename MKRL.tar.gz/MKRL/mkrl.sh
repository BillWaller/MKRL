#!/bin/bash
# mkrl.sh
# create record layout from COBOL File Descriptor or Data Structure
# usage: mkrl.sh FD_file_spec
# FD_file_spec identifies a COBOL File Descriptor or Data Structure
# Record Layout will be placed in `basename Fd_file_spec`".RL"

if [ $# != 1 ]; then
    echo "usage: FD_file_spec"
    exit 1
fi
if [ ! -f $1 ]; then
    echo $1 "file not found"
    exit 1
fi
file=$1
echo "       fd  Tmp-File." >TMP.FD
sed '/       fd/d' $file >>TMP.FD
if [ ! -x FD-PARSER ]; then
    make FD-PARSER
fi
./FD-PARSER
rm -f RL
make RL
./RL
rl_file=`basename $file | sed 's/\..*$//'`.RL
mv TMP.RL $rl_file
rm TMP.FD
