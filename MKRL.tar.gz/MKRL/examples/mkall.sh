#!/bin/bash
# mkall.sh
# create record layouts from COBOL file descriptors

IFS="
"
for file in `echo "AB
BD
BUMP
CLM
CLMSE
DAFM
DARAG
DARBC
DARCM
DARGL
DARHM
DARRAH
DARSP
DARTM
DCRF
DCT
DINC
DSPG
DSTC
DSTF
DSTT
DTAV
DTCC
DTNO
DTOC
DTPC
DTPM
DTPMSE
GLOBAL
HS
SPDT
TINMAST"`
do
    echo "---------------------------------"
    echo ../CPY/$file.FD
    ./mkrl.sh ../CPY/$file.FD
done
for file in `echo "DMAT
DTCF
DTLM
DTLMSE
DTOM
TO
DMAT
DTCF
DTLM
DTLMSE
DTOM
TO"`
do
    echo "---------------------------------"
    echo ../CPY/$file.FD
    ./mkrl.sh ../CPY2/$file.FD
done
